"""
Interpretable Classifier module for Python
==================================

easylogistic is a Python module which aims to build 
robust interpretable logistic models.
"""

from .LinearModel import (LassoClassifier,EnetClassifier,PosLassoClassifier,
    LassoClassifierCV,EnetClassifierCV,PosLassoClassifierCV)
from .MonoLogitTrans import (MonoLogitTrans,PlotComparableHistogram,PlotKS,get_data)

__version__ = '1.0.1'

__author__ = 'Su GuanXu <suguanxu@bbdservice.com>'


__all__ = ['LassoClassifier',
            'EnetClassifier',
            'PosLassoClassifier',
            'LassoClassifierCV',
            'EnetClassifierCV',
            'PosLassoClassifierCV',
            'MonoLogitTrans',
            'PlotComparableHistogram',
            'PlotKS',
            'get_data']


