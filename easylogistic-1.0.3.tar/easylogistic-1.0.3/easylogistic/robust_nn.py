'''

Author : 苏冠旭
update date : 20190717

本模块目前包含：


'''
import pandas as pd
import numpy as np
from sklearn.linear_model import Lasso,LassoCV,LassoLarsCV
from sklearn.linear_model import LogisticRegression,LogisticRegressionCV
from sklearn.metrics import roc_auc_score
import copy
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn import linear_model
from sklearn.preprocessing import PolynomialFeatures
import matplotlib.pyplot as plt
import tensorflow as tf
import random
import datetime



#############Model Classes###############
class Models(object):
    def __init__(self,max_iter=100,batch_size=1024):
        self.max_iter=max_iter
        self.batch_size=batch_size

    def predict_proba(self,dataX):
        y_proba = self.tf_sess.run(sess.tf_y_hat,feed_dict={self.tf_x:dataX})
        return(prob_result)

    def predict_log_proba(self,dataX):
        y_proba = self.tf_sess.run(sess.tf_y_hat,feed_dict={self.tf_x:dataX})
        return(np.log(y_proba))

    def predict(self,dataX):
        y_proba = self.tf_sess.run(sess.tf_y_hat,feed_dict={self.tf_x:dataX})
        labels = np.array(y_proba>0.5, dtype = np.int)
        return(labels)

    def plotLoss(self):
        fig,ax=plt.subplots(1,1)
        plt.plot(self.Losses)
        plt.ylabel("Loss")
        plt.rcParams['figure.figsize'] = (6, 3)
        ax.set_title('Losses Track',size=15)
        plt.show()

class LassoClassifier(Models):
    '''
Logistic Regression classifier with l1 penalty.

Parameters
----------
standardize : bool, default: False
    Specifies if each column should be normalized

max_iter : int, default: 100
    Maximum number of iterations of the optimization algorithm.

batch_size : int, default: 1024
    Number of rows of each batch of the batch training.
    If equal to number of rows of training data, then the algorithm
    would be equivalent to full scale training.

Q0 : float, default: 0.98
    If set to be a non-negative value less than 1, the loss function for
    the smaples of lable equals to 0 would be modified to exclude the
    elements greater than quantile Q0 before calculate the mean.

Q1 : float, default: 1.0
    If set to be a non-negative value less than 1, the loss function for
    the smaples of lable equals to 1 would be modified to exclude the
    elements greater than quantile Q1 before calculate the mean.

Attributes
----------

Losses : array
    Array of Loss recorded during training iterations.

Methods
-------
fit : optimize the parameters

predict_log_proba : calculate the linear predictor

predict_proba : calculate the probability of 1

predict : calculate the class

plotLoss : plot the trace plot of loss

Examples
--------
>>> from sklearn.datasets import load_iris
>>> from LinearModel import LassoClassifier
>>> X, y = load_iris(return_X_y=True)
>>> model = LassoClassifier().fit(X, y)
>>> model.predict(X[:2, :])
array([0, 0])
>>> model.predict_proba(X[:2, :]).shape
(2, 3)
    '''
    def __init__(self,max_iter=100,batch_size=1024,Q1=1,Q0=0.98):
        Models.__init__(self,max_iter,batch_size)
        self.Q0 = Q0
        self.Q1 = Q1

    def fit(self,dataX,dataY):
        sess, x, y_hat, Loss = mini_lasso(dataX,dataY,self.lambda_,self.max_iter,self.batch_size,\
                                                      self.standardize,y_track=True,start_point=self.start_point,\
                                                      Q0=self.Q0,Q1=self.Q1)
        self.tf_sess = sess
        self.tf_x = x
        self.tf_y_hat = y_hat
        self.Losses = Loss

def mini_lasso(dataX_,dataY_,num_hidden=32,max_iter=200,batch_size=1024,standardize=False,Q1=1,Q0=0.98):
    '''
    This function requires feature matrix, a column of label from training data,
    hyper varaible lambd, and maxinum number of iteration max_iter.
    The function give out the fitted coefficients of lasso as well as trace of loss function.
    The lasso would standardize the input data automatically!

    The optimazation would stop if loss function reduces less than 0.01%, or number of iterations reaches
    max_iter.
    '''
    dataX = copy.deepcopy(dataX_)
    dataY = copy.deepcopy(dataY_)


    x = tf.placeholder(dtype = tf.float32, shape=[None,dataX.shape[1]])
    y = tf.placeholder(dtype = tf.float32, shape=[None,1])
    l = tf.constant(lambd,dtype=tf.float32)

    tf.reset_default_graph()
    with tf.variable_scope('weight', initializer=tf.random_normal_initializer(),regularizer=regularizer):
        w1 = tf.Variable(tf.random_normal([dataX.shape[1],num_hidden], stddev=0.1,mean=0),name = 'w1',dtype=tf.float32)
        w2 = tf.Variable(tf.random_normal([num_hidden,num_hidden], stddev=0.1,mean=0),name = 'w2',dtype=tf.float32)
        w3 = tf.Variable(tf.random_normal([num_hidden,1], stddev=0.1,mean=0),name = 'w3',dtype=tf.float32)
    b1 = tf.Variable(tf.zeros([num_hidden]),name = 'b1',dtype=tf.float32)
    b2 = tf.Variable(tf.zeros([num_hidden]),name = 'b2',dtype=tf.float32)
    b3 = tf.Variable(tf.zeros([1]),name = 'b3',dtype=tf.float32)

    h1 = tf.nn.tanh(tf.matmul(x,w1) + b1)
    h2 = tf.nn.tanh(tf.matmul(h1,w2) + b2)
    y_hat_linear = tf.matmul(h2,w3)+b3
    y_hat = tf.sigmoid(h3)
    #loss = 10*tf.reduce_mean(-y*tf.log(tf.clip_by_value(y_hat,1e-10,1.0))-(1-y)*tf.log(tf.clip_by_value(1-y_hat,1e-10,1.0)))
    loss = 10*tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(labels = y, logits = y_hat_linear)) + lambd*tf.reduce_sum(tf.abs(beta))
    loss_pointwise = tf.nn.sigmoid_cross_entropy_with_logits(labels=y, logits=y_hat_linear)

    #loss = loss + lambd*tf.reduce_sum(tf.abs(beta))
    global_step = tf.Variable(0)
    learning_rate = tf.train.exponential_decay(0.5,global_step,decay_steps=max_iter/10,decay_rate=0.95)
    train_step = tf.train.AdamOptimizer(learning_rate).minimize(loss,global_step=global_step)
    sess = tf.Session()
    init_op = tf.group(tf.global_variables_initializer(),tf.local_variables_initializer())
    sess.run(init_op)
    Loss = []
    Y_HAT = []
    beta_HAT = []
    index_batch = [random.choices(range(dataY.shape[0]))[0] for i in range(batch_size)]
    batch_X = dataX[index_batch]
    batch_Y = dataY[index_batch]
    sess.run(train_step,feed_dict={x:batch_X,y:np.reshape(batch_Y,(batch_Y.shape[0],1))})
    Loss.append(sess.run(loss,feed_dict={x:dataX,y:np.reshape(dataY,(dataY.shape[0],1))}))
    sess.run(train_step,feed_dict={x:batch_X,y:np.reshape(batch_Y,(batch_Y.shape[0],1))})
    Loss.append(sess.run(loss,feed_dict={x:dataX,y:np.reshape(dataY,(dataY.shape[0],1))}))
    step_ = 2

    for i in range(20):
        step_ += 1
        index_batch = [random.choices(range(dataY.shape[0]))[0] for i in range(batch_size)]
        batch_X = dataX[index_batch]
        batch_Y = dataY[index_batch]
        sess.run(train_step,feed_dict={x:batch_X,y:np.reshape(batch_Y,(batch_Y.shape[0],1))})
        Loss.append(sess.run(loss,feed_dict={x:dataX,y:np.reshape(dataY,(dataY.shape[0],1))}))

    while (((Loss[-2]-Loss[-1])/(np.abs(Loss[-2])+1e-10)>.0001) or ((Loss[-2]-Loss[-1])<0) or step_<20) & (step_<=max_iter):
        step_ += 1
        index_batch = [random.choices(range(dataY.shape[0]))[0] for i in range(batch_size)]
        batch_X = dataX[index_batch]
        batch_Y = dataY[index_batch]

        if Q1<1 or Q0<1:
            batch_X_white = batch_X[batch_Y==0]
            batch_X_black = batch_X[batch_Y==1]
            batch_Y_white = batch_Y[batch_Y==0]
            batch_Y_black = batch_Y[batch_Y==1]

            Loss_white = sess.run(loss_pointwise,feed_dict={x:batch_X_white,y:np.reshape(batch_Y_white,(batch_Y_white.shape[0],1))})
            Loss_black = sess.run(loss_pointwise,feed_dict={x:batch_X_black,y:np.reshape(batch_Y_black,(batch_Y_black.shape[0],1))})
            Loss_white = np.reshape(Loss_white,max(Loss_white.shape))
            Loss_black = np.reshape(Loss_black,max(Loss_black.shape))

            white_NoOutlier = np.array(Loss_white<=np.quantile(Loss_white,Q0))
            black_NoOutlier = np.array(Loss_black<=np.quantile(Loss_black,Q1))

            batch_X = np.concatenate((batch_X_white[white_NoOutlier],batch_X_black[black_NoOutlier]))
            batch_Y = np.concatenate((batch_Y_white[white_NoOutlier],batch_Y_black[black_NoOutlier]))

        sess.run(train_step,feed_dict={x:batch_X,y:np.reshape(batch_Y,(batch_Y.shape[0],1))})
        Loss.append(sess.run(loss,feed_dict={x:dataX,y:np.reshape(dataY,(dataY.shape[0],1))}))
        if step_ % 20 == 0:
            time_ = datetime.datetime.now().strftime('%Y-%D %H:%M:%S')
            print(time_ + '\t'+str(step_) +'\t'+ str(Loss[-1]))

    return(sess,x,y_hat,Loss)