from distutils.core import setup

setup(
        name='easylogistic',
        version='1.0.3',
        description='BBD standard modeling module',
        author='Guanxu Su',
        author_email='suguanxu@bbdservice.com',
        url='http://git.bbdops.com/BBD_MODEL_standard_module/ModelingCode',
        packages=['easylogistic']
)